import boto3
from PIL import Image
from io import BytesIO

def lambda_handler(event, context):
    s3_client = boto3.client('s3')
    
    # Get the source bucket and key from the event
    source_bucket = event['Records'][0]['s3']['bucket']['name']
    source_key = event['Records'][0]['s3']['object']['key']
    
    # Download the original image from the source bucket
    response = s3_client.get_object(Bucket=source_bucket, Key=source_key)
    image_data = response['Body'].read()
    
    # Generate the thumbnail image using Pillow
    image = Image.open(BytesIO(image_data))
    image.thumbnail((100, 100))  # Adjust the size as per your requirement
    
    # Create a new in-memory stream for the thumbnail image
    thumbnail_bytes = BytesIO()
    image.save(thumbnail_bytes, format='JPEG')
    thumbnail_bytes.seek(0)
    
    # Save the thumbnail image to the thumbnail bucket
    thumbnail_bucket = 'thumbnail-bucket123'  # Replace with the name of your thumbnail bucket
    thumbnail_key = 'thumbnails/' + source_key  # Change the prefix or suffix as desired
    s3_client.upload_fileobj(thumbnail_bytes, thumbnail_bucket, thumbnail_key)
    
    return {
        'statusCode': 200,
        'body': 'Thumbnail created and saved successfully'
    }
